require('dotenv').config();
const fs=require('fs'),path=require('path'),http=require('http');
const [maj,min]=process.versions.node.split('.').map(Number);
if(maj<22||(maj===22&&min<13)){console.error('❌ Node.js 22.13 বা নতুন সংস্করণ লাগবে (আপনার: '+process.versions.node+'). https://nodejs.org থেকে LTS নামান।');process.exit(1)}
const express=require('express'),cors=require('cors'),{DatabaseSync}=require('node:sqlite');
const bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer');
const {Server}=require('socket.io');
fs.mkdirSync(path.join(__dirname,'uploads'),{recursive:true});
if(!process.env.JWT_SECRET){process.env.JWT_SECRET='dev_secret_change_me';console.warn('⚠ .env নেই: ডিফল্ট JWT_SECRET ব্যবহার হচ্ছে');}

// ---- SQLite ডাটাবেস (data.db ফাইলে নিজে থেকেই তৈরি হয়) ----
const db=new DatabaseSync(path.join(__dirname,'data.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,nid TEXT UNIQUE NOT NULL,
  mobile TEXT UNIQUE NOT NULL,address TEXT NOT NULL,photo TEXT,password TEXT NOT NULL,
  share_solo INTEGER DEFAULT 0,lat REAL,lng REAL,loc_at TEXT);
CREATE TABLE IF NOT EXISTS travel_groups(
  id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT UNIQUE NOT NULL,owner INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS group_members(
  group_id INTEGER NOT NULL,user_id INTEGER NOT NULL,PRIMARY KEY(group_id,user_id));`);
const S={
  userById:db.prepare('SELECT * FROM users WHERE id=?'),
  userByMobile:db.prepare('SELECT * FROM users WHERE mobile=?'),
  addUser:db.prepare('INSERT INTO users(name,nid,mobile,address,photo,password) VALUES(?,?,?,?,?,?)'),
  setShare:db.prepare('UPDATE users SET share_solo=? WHERE id=?'),
  setLoc:db.prepare('UPDATE users SET lat=?,lng=?,loc_at=? WHERE id=?'),
  addGroup:db.prepare('INSERT INTO travel_groups(name,code,owner) VALUES(?,?,?)'),
  groupByCode:db.prepare('SELECT * FROM travel_groups WHERE code=?'),
  addMember:db.prepare('INSERT OR IGNORE INTO group_members(group_id,user_id) VALUES(?,?)'),
  myGroups:db.prepare('SELECT g.* FROM travel_groups g JOIN group_members m ON m.group_id=g.id WHERE m.user_id=? ORDER BY g.id DESC'),
  members:db.prepare('SELECT u.id,u.name,u.photo,u.mobile,u.lat,u.lng,u.loc_at FROM users u JOIN group_members m ON m.user_id=u.id WHERE m.group_id=?'),
  mapUsers:db.prepare(`SELECT * FROM users WHERE lat IS NOT NULL AND (share_solo=1 OR id IN
    (SELECT user_id FROM group_members WHERE group_id IN (SELECT group_id FROM group_members WHERE user_id=?)))`),
  stale:db.prepare(`SELECT g.id gid,g.name gname,u.name uname,u.loc_at FROM travel_groups g
    JOIN group_members m ON m.group_id=g.id JOIN users u ON u.id=m.user_id WHERE u.loc_at IS NOT NULL AND u.loc_at<?`)
};
const me=u=>({id:u.id,name:u.name,photo:u.photo,mobile:u.mobile,shareSolo:!!u.share_solo});
const pin=u=>({id:u.id,name:u.name,photo:u.photo,lat:u.lat,lng:u.lng,at:u.loc_at});
const groupOut=g=>({_id:g.id,name:g.name,code:g.code,members:S.members.all(g.id).map(u=>
  ({_id:u.id,name:u.name,photo:u.photo,mobile:u.mobile,loc:u.lat!=null?{lat:u.lat,lng:u.lng,at:u.loc_at}:undefined}))});

const app=express(),server=http.createServer(app);
const io=new Server(server,{cors:{origin:'*'}});
app.use(cors(),express.json());
app.use('/uploads',express.static(path.join(__dirname,'uploads')));
const upload=multer({storage:multer.diskStorage({destination:path.join(__dirname,'uploads'),
  filename:(r,f,cb)=>cb(null,Date.now()+path.extname(f.originalname))}),
  limits:{fileSize:2e6},fileFilter:(r,f,cb)=>cb(null,/^image\//.test(f.mimetype))});
const sign=u=>jwt.sign({id:u.id},process.env.JWT_SECRET,{expiresIn:'30d'});
const auth=(req,res,next)=>{try{
  const t=(req.headers.authorization||'').split(' ')[1];
  req.user=S.userById.get(jwt.verify(t,process.env.JWT_SECRET).id);
  if(!req.user)throw 0;next();
}catch{res.status(401).json({msg:'আবার লগইন করুন'})}};
const wrap=f=>(req,res)=>{try{f(req,res)}catch(e){console.error(e);res.status(500).json({msg:'সার্ভারে সমস্যা হয়েছে'})}};

// ---- রেজিস্ট্রেশন / লগইন ----
app.post('/api/auth/register',(req,res,next)=>upload.single('photo')(req,res,e=>e?res.status(400).json({msg:'ছবি ২MB এর কম হতে হবে'}):next()),async(req,res)=>{
  try{
    const {name,nid,mobile,address,password}=req.body;
    if(!req.file)return res.status(400).json({msg:'ছবি দিন'});
    if(!/^(\d{10}|\d{13}|\d{17})$/.test(nid||''))return res.status(400).json({msg:'সঠিক NID দিন'});
    if(!/^01[3-9]\d{8}$/.test(mobile||''))return res.status(400).json({msg:'সঠিক মোবাইল নম্বর দিন'});
    if(!name||!address||!password||password.length<6)return res.status(400).json({msg:'সব তথ্য দিন (পাসওয়ার্ড ৬+ অক্ষর)'});
    const r=S.addUser.run(name,nid,mobile,address,'/uploads/'+req.file.filename,await bcrypt.hash(password,10));
    const u=S.userById.get(Number(r.lastInsertRowid));
    res.json({token:sign(u),user:me(u)});
  }catch(e){console.error(e);res.status(400).json({msg:/UNIQUE/i.test(String(e.message))?'NID বা মোবাইল আগে থেকেই নিবন্ধিত':'ত্রুটি হয়েছে'})}
});
app.post('/api/auth/login',async(req,res)=>{
  const u=S.userByMobile.get(req.body.mobile||'');
  if(!u||!(await bcrypt.compare(req.body.password||'',u.password)))return res.status(401).json({msg:'মোবাইল বা পাসওয়ার্ড ভুল'});
  res.json({token:sign(u),user:me(u)});
});
app.get('/api/me',auth,(req,res)=>res.json(me(req.user)));

// ---- গ্রুপ ----
app.post('/api/groups',auth,wrap((req,res)=>{
  const name=(req.body.name||'').trim();if(!name)return res.status(400).json({msg:'গ্রুপের নাম দিন'});
  let code,r;
  for(let i=0;i<5&&!r;i++){code=Math.random().toString(36).slice(2,8).toUpperCase();
    try{r=S.addGroup.run(name,code,req.user.id)}catch{}}
  S.addMember.run(Number(r.lastInsertRowid),req.user.id);
  res.json({_id:Number(r.lastInsertRowid),name,code});
}));
app.post('/api/groups/join',auth,wrap((req,res)=>{
  const g=S.groupByCode.get((req.body.code||'').trim().toUpperCase());
  if(!g)return res.status(404).json({msg:'গ্রুপ পাওয়া যায়নি'});
  S.addMember.run(g.id,req.user.id);res.json({_id:g.id,name:g.name});
}));
app.get('/api/groups',auth,wrap((req,res)=>res.json(S.myGroups.all(req.user.id).map(groupOut))));

// ---- লোকেশন ----
app.post('/api/share',auth,wrap((req,res)=>{
  S.setShare.run(req.body.on?1:0,req.user.id);res.json(me(S.userById.get(req.user.id)));
}));
app.post('/api/location',auth,wrap((req,res)=>{
  const lat=Number(req.body.lat),lng=Number(req.body.lng);
  if(!isFinite(lat)||!isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return res.status(400).json({msg:'ভুল লোকেশন'});
  S.setLoc.run(lat,lng,new Date().toISOString(),req.user.id);
  const u=S.userById.get(req.user.id),p=pin(u);
  S.myGroups.all(u.id).forEach(g=>io.to('g:'+g.id).emit('loc',p));
  if(u.share_solo)io.to('public').emit('loc',p);
  res.json({ok:true});
}));
app.get('/api/map',auth,wrap((req,res)=>res.json(S.mapUsers.all(req.user.id).map(pin))));

// ---- Socket: লাইভ আপডেট ----
io.use((s,next)=>{try{
  s.user=S.userById.get(jwt.verify(s.handshake.auth.token,process.env.JWT_SECRET).id);
  s.user?next():next(new Error('auth'));
}catch{next(new Error('auth'))}});
io.on('connection',s=>{s.join('public');S.myGroups.all(s.user.id).forEach(g=>s.join('g:'+g.id))});

// ---- হারিয়ে যাওয়া সদস্যের সতর্কতা (১০ মিনিট লোকেশন না এলে) ----
setInterval(()=>{try{
  S.stale.all(new Date(Date.now()-10*60*1000).toISOString()).forEach(r=>
    io.to('g:'+r.gid).emit('alert',{group:r.gname,name:r.uname,lastSeen:r.loc_at}));
}catch(e){console.error(e)}},60000);

const PORT=process.env.PORT||5000;
server.listen(PORT,()=>console.log('✅ Server running on port '+PORT+' (SQLite: data.db)'));
