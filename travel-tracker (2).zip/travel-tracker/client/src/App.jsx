import {useEffect,useRef,useState} from 'react';
import {APIProvider,Map,AdvancedMarker,InfoWindow,useMap} from '@vis.gl/react-google-maps';
import {io} from 'socket.io-client';
import Hero from './Hero.jsx';

const STALE=10*60*1000;
const GKEY=import.meta.env.VITE_GOOGLE_MAPS_KEY;
const api=async(url,opt={},token)=>{
  const h={...(opt.body instanceof FormData?{}:{'Content-Type':'application/json'}),...(token?{Authorization:'Bearer '+token}:{})};
  let r,txt='',d={};
  try{r=await fetch(url,{...opt,headers:h});txt=await r.text();d=txt?JSON.parse(txt):{}}catch{}
  if(!r||!txt||!r.ok)throw new Error(d.msg||'সার্ভারে সংযোগ হচ্ছে না। আরেকটি টার্মিনালে server ফোল্ডারে npm start চালু আছে কিনা দেখুন।');
  return d;
};
const isStale=u=>Date.now()-new Date(u.at||u.loc?.at||0)>STALE;
function Fly({to}){const m=useMap();useEffect(()=>{if(to&&m){m.panTo({lat:to.lat,lng:to.lng});m.setZoom(16)}},[to,m]);return null}

function Auth({onAuth}){
  const [reg,setReg]=useState(false),[err,setErr]=useState(''),[prev,setPrev]=useState(''),[busy,setBusy]=useState(false);
  const submit=async e=>{e.preventDefault();setErr('');setBusy(true);
    try{const fd=new FormData(e.target);
      const d=reg?await api('/api/auth/register',{method:'POST',body:fd})
        :await api('/api/auth/login',{method:'POST',body:JSON.stringify(Object.fromEntries(fd))});
      onAuth(d)}catch(x){setErr(x.message)}setBusy(false)};
  return <div className="auth">
    <section className="hero">
      <div className="brand"><svg width="34" height="34" viewBox="0 0 24 24"><path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z" fill="#E4572E"/><circle cx="12" cy="9" r="3" fill="#fff"/></svg>পথসাথী</div>
      <div style={{position:'relative',zIndex:2}}><h1>একসাথে চলুন, কেউ হারাবেন না</h1>
        <p>দলের সবার অবস্থান এক মানচিত্রে। একা ঘুরলেও থাকুন সবার চোখের সামনে।</p></div>
      <Hero/>
    </section>
    <section className="formwrap">
      <form className="card" onSubmit={submit}>
        <h2>{reg?'নতুন অ্যাকাউন্ট খুলুন':'আবার স্বাগতম'}</h2>
        {reg&&<>
          <label className="photo-pick">{prev?<img src={prev} alt=""/>:<span className="ph">📷</span>}
            <span>আপনার ছবি দিন</span>
            <input type="file" name="photo" accept="image/*" required onChange={e=>e.target.files[0]&&setPrev(URL.createObjectURL(e.target.files[0]))}/></label>
          <label className="field">পুরো নাম<input name="name" required/></label>
          <label className="field">NID নম্বর<input name="nid" inputMode="numeric" required/></label>
          <label className="field">ঠিকানা<input name="address" required/></label></>}
        <label className="field">মোবাইল নম্বর<input name="mobile" inputMode="tel" placeholder="01XXXXXXXXX" required/></label>
        <label className="field">পাসওয়ার্ড<input name="password" type="password" minLength={6} required/></label>
        {err&&<div className="err" role="alert">{err}</div>}
        <button className="btn sun" disabled={busy}>{busy?'অপেক্ষা করুন…':reg?'অ্যাকাউন্ট খুলুন':'লগইন করুন'}</button>
        <button type="button" className="link" onClick={()=>{setReg(!reg);setErr('')}}>{reg?'আগে থেকেই অ্যাকাউন্ট আছে? লগইন করুন':'নতুন? অ্যাকাউন্ট খুলুন'}</button>
      </form>
    </section>
  </div>;
}

export default function App(){
  const [auth,setAuth]=useState(()=>JSON.parse(localStorage.getItem('auth')||'null'));
  const [pins,setPins]=useState({}),[groups,setGroups]=useState([]),[alerts,setAlerts]=useState([]);
  const [share,setShare]=useState(false),[name,setName]=useState(''),[code,setCode]=useState(''),[focus,setFocus]=useState(null),[sel,setSel]=useState(null),[,tick]=useState(0);
  const token=auth?.token,myId=auth?.user.id;
  const login=d=>{localStorage.setItem('auth',JSON.stringify(d));setAuth(d)};
  const loadGroups=()=>api('/api/groups',{},token).then(setGroups);

  useEffect(()=>{ if(!token)return;
    setShare(auth.user.shareSolo);loadGroups();
    api('/api/map',{},token).then(l=>setPins(Object.fromEntries(l.map(u=>[u.id,u])))).catch(()=>{});
    const s=io({auth:{token}});
    s.on('loc',u=>setPins(p=>({...p,[u.id]:u})));
    s.on('alert',a=>setAlerts(x=>[`${a.name} (${a.group}) ১০ মিনিটের বেশি সময় লোকেশন পাঠায়নি`,...x.filter(t=>!t.startsWith(a.name))].slice(0,4)));
    const t=setInterval(()=>tick(n=>n+1),30000);
    return()=>{s.close();clearInterval(t)};
  },[token]);

  useEffect(()=>{ if(!token)return;let last=0;
    const w=navigator.geolocation.watchPosition(p=>{
      if(Date.now()-last<15000)return;last=Date.now();
      api('/api/location',{method:'POST',body:JSON.stringify({lat:p.coords.latitude,lng:p.coords.longitude})},token).catch(()=>{});
    },()=>setAlerts(a=>['লোকেশন চালু করার অনুমতি দিন, নইলে আপনি মানচিত্রে দেখা যাবেন না',...a]),{enableHighAccuracy:true});
    return()=>navigator.geolocation.clearWatch(w);
  },[token]);

  if(!token)return <Auth onAuth={login}/>;
  const toggle=async()=>{await api('/api/share',{method:'POST',body:JSON.stringify({on:!share})},token);setShare(!share)};
  const create=async()=>{if(name.trim()){await api('/api/groups',{method:'POST',body:JSON.stringify({name})},token);setName('');loadGroups()}};
  const join=async()=>{try{await api('/api/groups/join',{method:'POST',body:JSON.stringify({code})},token);setCode('');loadGroups()}catch(e){setAlerts(a=>[e.message,...a])}};
  const mine=pins[myId];
  const status=m=>{const p=pins[m._id]||m;return !p.loc&&!p.lat?'':isStale(p)?'stale':'live'};
  const go=m=>{const p=pins[m._id]||(m.loc?.lat&&{lat:m.loc.lat,lng:m.loc.lng});if(p)setFocus({lat:p.lat,lng:p.lng,k:Date.now()})};

  return <div className="shell">
    {GKEY?<APIProvider apiKey={GKEY} language="bn" region="BD">
      <Map defaultCenter={{lat:23.8,lng:90.4}} defaultZoom={7} mapId="DEMO_MAP_ID" disableDefaultUI gestureHandling="greedy" style={{width:'100%',height:'100%'}}>
        <Fly to={focus}/>
        {Object.values(pins).map(u=><AdvancedMarker key={u.id} position={{lat:u.lat,lng:u.lng}} onClick={()=>setSel(u.id)}>
          <div className={`pin ${isStale(u)?'stale':'live'} ${u.id===myId?'mine':''}`}><img src={u.photo} alt=""/><span>{u.id===myId?'আমি':u.name}</span></div>
        </AdvancedMarker>)}
        {pins[sel]&&<InfoWindow position={{lat:pins[sel].lat,lng:pins[sel].lng}} pixelOffset={[0,-78]} onCloseClick={()=>setSel(null)}>
          <b>{pins[sel].name}</b><br/>সর্বশেষ আপডেট: {new Date(pins[sel].at).toLocaleTimeString('bn-BD')}</InfoWindow>}
      </Map></APIProvider>
      :<div className="nokey"><div><h3>Google Maps key নেই</h3><p>client/.env ফাইলে VITE_GOOGLE_MAPS_KEY বসিয়ে npm run dev আবার চালু করুন।</p></div></div>}

    <button className="locate" aria-label="আমার অবস্থান দেখুন" onClick={()=>mine&&setFocus({lat:mine.lat,lng:mine.lng,k:Date.now()})}>◎</button>
    <div className="legend"><span><i style={{background:'var(--live)'}}/>লাইভ</span><span><i style={{background:'var(--stale)'}}/>১০ মিনিটের বেশি আগে</span><span><i style={{background:'var(--sun)'}}/>আমি</span></div>

    <aside className="panel">
      <div className="me"><img src={auth.user.photo} alt=""/><div><b>{auth.user.name}</b><small>{auth.user.mobile}</small></div>
        <button className="btn sm" onClick={()=>{localStorage.clear();setAuth(null)}}>বের হোন</button></div>
      <div className="scroll">
        <label className="toggle"><div>একা ভ্রমণ করছি<small>চালু করলে সবাই মানচিত্রে আপনাকে দেখবে</small></div>
          <input type="checkbox" checked={share} onChange={toggle}/><span className="sw"/></label>
        {alerts.map((a,i)=><div className="alert" key={i} role="alert">{a}</div>)}
        <h3 className="sec">নতুন গ্রুপ</h3>
        <div className="row"><input value={name} onChange={e=>setName(e.target.value)} placeholder="যেমন: কক্সবাজার ট্যুর"/><button className="btn sm" onClick={create}>তৈরি করুন</button></div>
        <h3 className="sec">কোড দিয়ে যোগ দিন</h3>
        <div className="row"><input value={code} onChange={e=>setCode(e.target.value)} placeholder="৬ অক্ষরের কোড"/><button className="btn ghost sm" onClick={join}>যোগ দিন</button></div>
        <h3 className="sec">আমার গ্রুপ</h3>
        {groups.length===0&&<p style={{color:'var(--mute)',margin:0}}>এখনো কোনো গ্রুপ নেই। একটি গ্রুপ খুলে কোডটি বন্ধুদের পাঠান।</p>}
        {groups.map(g=><div className="group" key={g._id}>
          <header><b>{g.name}</b><button className="code" title="কপি করুন" onClick={()=>navigator.clipboard?.writeText(g.code)}>{g.code}</button></header>
          {g.members.map(m=><button className="member" key={m._id} onClick={()=>go(m)}><img src={m.photo} alt=""/>{m.name}<span className={'dot '+status(m)}/></button>)}
        </div>)}
      </div>
    </aside>
  </div>;
}
