export default function Hero(){
 return <svg viewBox="0 0 800 520" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
  <circle cx="620" cy="120" r="62" fill="#FFF3C4" opacity=".9"/>
  <path d="M0 330 L130 210 L230 300 L360 170 L500 310 L620 230 L800 340 V520 H0Z" fill="#2E8B6B" opacity=".55"/>
  <path d="M0 380 L110 300 L210 360 L330 260 L470 370 L590 300 L800 390 V520 H0Z" fill="#157257"/>
  <path d="M0 430 C150 390 260 470 420 430 S680 400 800 440 V520 H0Z" fill="#0E4A3B"/>
  <path d="M-10 470 C140 440 260 500 420 468 S680 450 810 480 V520 H0Z" fill="#1B6E9B" opacity=".85"/>
  <path d="M120 440 Q300 300 440 360 T690 250" fill="none" stroke="#fff" stroke-width="4" stroke-dasharray="4 12" stroke-linecap="round"/>
  <g transform="translate(690 190)"><path d="M0 60 C-34 20 -34 -22 0 -22 C34 -22 34 20 0 60Z" fill="#E4572E" stroke="#fff" stroke-width="4"/><circle cx="0" cy="0" r="12" fill="#fff"/></g>
  <g transform="translate(120 440)"><circle r="11" fill="#F6B91A" stroke="#fff" stroke-width="4"/></g>
  <g fill="#082F27" transform="translate(300 455)"><path d="M0 0 H70 L58 14 H12Z"/><path d="M35 -34 V0 L64 -4Z" fill="#F6B91A"/><rect x="34" y="-38" width="2" height="38"/></g>
 </svg>}
